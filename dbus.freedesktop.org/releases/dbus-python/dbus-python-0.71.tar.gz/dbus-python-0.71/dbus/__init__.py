from _dbus import *
from types import *

version = (0, 70, 0)
_dbus_main_loop_setup_function = None
