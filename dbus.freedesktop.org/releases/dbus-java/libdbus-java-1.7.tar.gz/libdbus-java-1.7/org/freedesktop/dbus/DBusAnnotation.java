package org.freedesktop.dbus;

public @interface DBusAnnotation
{
   String value();
}
