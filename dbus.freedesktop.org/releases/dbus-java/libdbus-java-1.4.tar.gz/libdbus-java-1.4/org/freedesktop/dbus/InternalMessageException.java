package org.freedesktop.dbus;

public class InternalMessageException extends DBusExecutionException
{
   public InternalMessageException(String message)
   {
      super (message);
   }
}
