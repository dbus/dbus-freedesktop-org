package org.freedesktop.dbus.test;

import org.freedesktop.dbus.DBusException;
import org.freedesktop.dbus.DBusInterface;
import org.freedesktop.dbus.DBusSignal;
import org.freedesktop.dbus.UInt32;
import org.freedesktop.dbus.Variant;
/**
 * A sample signal with two parameters
 */
public interface TestSignalInterface extends DBusInterface
{
   public static class TestSignal extends DBusSignal
   {
      public final String value;
      public final UInt32 number;
      /**
       * Create a signal.
       */
      public TestSignal(String path, String value, UInt32 number) throws DBusException
      {
         super(path, value, number);
         this.value = value;
         this.number = number;
      }
   }
   public static class TestArraySignal extends DBusSignal
   {
      public final TestStruct2<String[],Variant> v;
      public TestArraySignal(String path, TestStruct2<String[],Variant> v) throws DBusException
      {
         super(path, v);
         this.v = v;
      }
   }
}
