package org.freedesktop.dbus;
/**
 * Returning this class indicates that a method will not reply and that you should not wait for one.
 */
public final class DBusNoReply
{
}
