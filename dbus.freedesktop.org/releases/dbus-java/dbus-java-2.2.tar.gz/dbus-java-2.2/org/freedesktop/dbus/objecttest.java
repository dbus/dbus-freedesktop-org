package org.freedesktop.dbus;

public class objecttest
{
   public static class O implements DBusInterface
   {
      public boolean isRemote() { return false; }
   }
   public static void main(String[] args)
   {
      ObjectTree tree = new ObjectTree();
      System.out.println(tree);
      tree.add("/aoeu", new O(), "<foo/>\n");
      System.out.println(tree);
      System.out.println(tree.Introspect("/"));
      tree.add("/org/foo", new O(), "<foo/>\n");
      tree.add("/org/bar", new O(), "<foo/>\n");
      tree.add("/org/bar/1", new O(), "<foo/>\n");
      tree.add("/org/bar/2", new O(), "<foo/>\n");
      tree.add("/org/bar/3", new O(), "<foo/>\n");
      tree.add("/org/bar/4", new O(), "<foo/>\n");
      System.out.println(tree);
      System.out.println(tree.Introspect("/"));
      System.out.println(tree.Introspect("/org"));
      System.out.println(tree.Introspect("/org/bar"));
      System.out.println(tree.Introspect("/org/bar/1"));
   }
}
